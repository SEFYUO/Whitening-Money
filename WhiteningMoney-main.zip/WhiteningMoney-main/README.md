# WhiteningMoney

# FR
- Script permettant de blanchir l'argent sale sur FiveM
- Configuration du pourcentage pris par le blanchisseur côté client
- Optimisation 0.01 ms
- Lib : RageUI
- Pour tout support Yatox#3203

# EN
- Script to launder dirty money on FiveM
- Configuration of the percentage taken by the launderer on the client side
- Optimization 0.01 ms
- Lib: RageUI
- For any question Yatox#3203

# Preview
- https://streamable.com/6zk1vc
